﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Login_ProyectoFinal
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string pathName = @".\Registro_Usuario.txt";
        

        public MainWindow()
        {
            InitializeComponent();
            VerificarArchivo();
        }

        private void VerificarArchivo()
        {
            try
            {
                if (!File.Exists(pathName))
                {
                    File.Create(pathName).Dispose();
                    EscribirArchivo("superusario, administrador,Marcelo,#marcelo123");
                    
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void EscribirArchivo(string mensaje)
        {
            StreamWriter tuberiaEscritura = File.AppendText(pathName);
            tuberiaEscritura.WriteLine(mensaje);
            tuberiaEscritura.Close();
        }

        private void btn_registrar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string usario = txt_user.Text.Trim();
                string password = pwb_contra.Password.Trim();
                if (usario != "" && password != "")
                {
                    if (ValidarUsario(usario, password))
                    {
                        //datos correctos
                        MessageBox.Show("Bienvenido " + usario);
                        VentanaPrincipal principal = new VentanaPrincipal();
                        this.Hide();
                        principal.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        //datos incorrectos.MessageBox
                        MessageBox.Show("Usuario incorrecto");
                    }
                }
                else
                {
                    MessageBox.Show("Ingrese el usuario y la contraseña");
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private bool ValidarUsario(string usario, string password)
        {
            bool resultado = false;
            string[] datosUsuario;
            StreamReader tuberiaLectura = File.OpenText(pathName);
            string linea = tuberiaLectura.ReadLine();
            while (linea != null)
            {
                datosUsuario = linea.Split(',');
                if (usario == datosUsuario[2] && password == datosUsuario[3])
                {
                    resultado = true;
                    break;
                }
                linea = tuberiaLectura.ReadLine();
            }
            tuberiaLectura.Close();
            return resultado;
        }
    }
}
