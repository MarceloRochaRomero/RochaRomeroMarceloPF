﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Login_ProyectoFinal
{
    /// <summary>
    /// Lógica de interacción para VentaProducto.xaml
    /// </summary>
    public partial class VentaProducto : Window
    {
        string pathNameAuxiliar = @"C:\Users\Hogar\Desktop\Productos_Eliminados.txt";
        string pathName = @"C:\Users\Hogar\Desktop\Registro_Productos.txt";

        public VentaProducto()
        {
            InitializeComponent();
            MostrarProductosDG();
        }

        private void btn_modificiar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if ((File.Exists(pathName)))
                {
                    string idProducto = txt_id.Text;
                    string producto = txt_nom.Text;
                    string precioVenta = txt_precioVenta.Text;
                    string precioCompra = txt_precioCompra.Text;
                    string cantidad = txt_cantidad.Text;
                    if (producto != "" && idProducto != "" && precioVenta != "" && precioCompra != "" && cantidad != "")
                    {
                        if (ValidarId(idProducto))
                        {
                            StreamWriter tuberiaEscritura = File.AppendText(pathName);
                            tuberiaEscritura.WriteLine(idProducto + "," + producto + "," + precioVenta + "," + precioCompra + "," + cantidad);
                            tuberiaEscritura.Close();
                            MessageBox.Show("Producto grabado con exito");
                            txt_nom.Text = "";
                            txt_id.Text = "";
                            txt_precioVenta.Text = "";
                            txt_precioCompra.Text = "";
                            txt_cantidad.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("El id debe de ser unico");
                        }
                    }
                    else
                    {
                        MessageBox.Show("No se permite vacio");
                    }
                }
                else
                {
                    File.Create(pathName);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private bool ValidarId(string idProducto)
        {
            bool respuesta = true;
            string[] datosSeparados;
            StreamReader tuberiaLectura = File.OpenText(pathName);
            string linea = tuberiaLectura.ReadLine();

            while (linea != null)
            {
                datosSeparados = linea.Split(',');
                if (idProducto == datosSeparados[0])
                {
                    respuesta = false;
                    break;
                }
                linea = tuberiaLectura.ReadLine();
            }
            tuberiaLectura.Close();
            return respuesta;
        }

        private void MostrarProductosDG()
        {
            try
            {
                if (File.Exists(pathName))
                {

                    Producto producto;
                    string id, nombre, precioCompra, PrecioVenta, cantidad;
                    string[] datosProducto;

                    List<Producto> listaProductos = new List<Producto>();
                    StreamReader tuberiaLectura = File.OpenText(pathName);
                    string linea = tuberiaLectura.ReadLine();
                    while (linea != null)
                    {
                        datosProducto = linea.Split(',');
                        id = datosProducto[0];
                        nombre = datosProducto[1];
                        precioCompra = datosProducto[2];
                        PrecioVenta = datosProducto[3];
                        cantidad = datosProducto[4];

                        producto = new Producto(id, nombre, precioCompra, PrecioVenta, cantidad);

                        listaProductos.Add(producto);

                        producto = null;
                        linea = tuberiaLectura.ReadLine();
                    }
                    tuberiaLectura.Close();

                    dg_productos.ItemsSource = listaProductos;
                }
                else
                {
                    MessageBox.Show("El archivo no existe");
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show("El archivo no existe");
            }
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Producto producto = new Producto();
            producto = (Producto)dg_productos.SelectedItem;
            txt_id.Text = producto.Id;
        }

        private void btn_eliminar_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string idEliminar = txt_elim.Text;
                if (idEliminar != "")
                {
                    string linea;
                    string[] datosProducto;
                    char separador = ',';
                    bool eliminado = false;
                    StreamReader tuberiaLectura = File.OpenText(pathName);
                    StreamWriter tuberiaEscritura = File.AppendText(pathNameAuxiliar);
                    linea = tuberiaLectura.ReadLine();
                    while (linea != null)
                    {
                        datosProducto = linea.Split(separador);
                        if (idEliminar != datosProducto[0])
                        {
                            tuberiaEscritura.WriteLine(linea);
                        }
                        else
                        {
                            eliminado = true;
                        }
                        linea = tuberiaLectura.ReadLine();
                    }
                    tuberiaEscritura.Close();
                    tuberiaLectura.Close();

                    File.Delete(pathName);
                    File.Move(pathNameAuxiliar, pathName);
                    File.Delete(pathNameAuxiliar);
                    if (eliminado)
                    {
                        MessageBox.Show("Eliminación con exito.");
                    }
                    else
                    {
                        MessageBox.Show("Error. No existe el Cliente");
                    }
                    txt_elim.Text = "";
                }
                else
                {
                    MessageBox.Show("No se permite vacio");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se permite vacio");
            }
        }

        private void btn_mostrar_Click(object sender, RoutedEventArgs e)
        {
            MostrarProductosDG();
        }

        private void btn_salir_Click(object sender, RoutedEventArgs e)
        {
            VentanaPrincipal principal = new VentanaPrincipal();
            this.Hide();
            principal.ShowDialog();
            this.Close();
        }
    }
}
