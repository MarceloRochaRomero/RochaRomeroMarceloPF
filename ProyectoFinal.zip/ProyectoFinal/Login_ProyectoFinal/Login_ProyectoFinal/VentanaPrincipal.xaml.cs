﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Login_ProyectoFinal
{
    /// <summary>
    /// Lógica de interacción para VentanaPrincipal.xaml
    /// </summary>
    public partial class VentanaPrincipal : Window
    {
        public VentanaPrincipal()
        {
            InitializeComponent();
        }

        private void btn_productos_Click(object sender, RoutedEventArgs e)
        {
            VentaProducto principal = new VentaProducto();
            this.Hide();
            principal.ShowDialog();
            this.Close();
        }

        private void btn_QS_Click(object sender, RoutedEventArgs e)
        {
            Nosotros principal = new Nosotros();
            this.Hide();
            principal.ShowDialog();
            this.Close();
        }

        private void btn_Salir_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("¿Estas seguro de querer salir?", "Eliminar", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) == MessageBoxResult.Yes)
            {
                this.Close();
            }
            else
            {
                btn_Salir.IsEnabled = true;
            }
        }
    }
}
